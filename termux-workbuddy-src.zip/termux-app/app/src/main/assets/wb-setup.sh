# WorkBuddy 一键环境
# 由 $PREFIX/etc/bash.bashrc 自动 source：首次打开自动安装，之后每次打开直接启动。
# 手动执行：bash ~/.wb-setup.sh

WB_ROOTFS="$PREFIX/var/lib/proot-distro/installed-rootfs/debian"
WB_READY="$HOME/.wb-ready"
WB_PID="$HOME/.wb.pid"
WB_DEB_URL="https://download.codebuddy.cn/workbuddy/saas/linux-arm64-deb/WorkBuddy-linux-arm64-deb-5.6.2.40046327-c7b525f3.deb"

_wb_start() {
    if [ -f "$WB_PID" ] && kill -0 "$(cat "$WB_PID" 2>/dev/null)" 2>/dev/null; then
        echo "[WorkBuddy] 已在运行，VNC 连 127.0.0.1:5900"
        return 0
    fi
    nohup proot-distro login debian -- bash /root/wb-start.sh > "$HOME/wb-run.log" 2>&1 &
    echo $! > "$WB_PID"
    echo "[WorkBuddy] 已启动，用 VNC 客户端连 127.0.0.1:5900"
}

_wb_install() {
    echo "[WorkBuddy] 首次运行，开始安装（约 2GB，请保持 Termux 在前台）"

    pkg update -y > /dev/null 2>&1
    pkg install -y proot-distro || { echo "[WorkBuddy] proot-distro 安装失败"; return 1; }

    if [ ! -d "$WB_ROOTFS" ]; then
        proot-distro install debian || { echo "[WorkBuddy] Debian 安装失败"; return 1; }
    fi

    mkdir -p "$WB_ROOTFS/root"

    cat > "$WB_ROOTFS/root/wb-install.sh" << 'EOS'
#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends \
    wget ca-certificates \
    libgtk-3-0 libnotify4 libnss3 libxss1 libxtst6 xdg-utils libatspi2.0-0 \
    libuuid1 libsecret-1-0 libasound2 libgbm1 libdrm2 \
    xvfb x11vnc dbus-x11 fonts-noto-cjk
wget -O /tmp/wb.deb "https://download.codebuddy.cn/workbuddy/saas/linux-arm64-deb/WorkBuddy-linux-arm64-deb-5.6.2.40046327-c7b525f3.deb"
dpkg -i /tmp/wb.deb || apt-get -f install -y
rm -f /tmp/wb.deb
EOS

    cat > "$WB_ROOTFS/root/wb-start.sh" << 'EOS'
#!/bin/bash
export DISPLAY=:1
Xvfb :1 -screen 0 1280x800x24 > /tmp/xvfb.log 2>&1 &
sleep 1
x11vnc -display :1 -forever -nopw -shared -rfbport 5900 > /tmp/vnc.log 2>&1 &
exec dbus-run-session -- /opt/WorkBuddy/workbuddy --no-sandbox --disable-gpu --disable-dev-shm-usage
EOS

    proot-distro login debian -- bash /root/wb-install.sh || {
        echo "[WorkBuddy] 安装失败，看上面输出；可重试：bash ~/.wb-setup.sh"
        return 1
    }

    touch "$WB_READY"
    echo "[WorkBuddy] 安装完成"
    return 0
}

_wb_main() {
    if [ ! -f "$WB_READY" ]; then
        _wb_install || return 0
    fi
    _wb_start
    return 0
}

_wb_main
